# LUCKY GRAPHICS Android App (starter project)

A modern Android WebView app prototype for LUCKY GRAPHICS. Includes a home screen, services, sample gallery cards, order form routed to WhatsApp, contact details, and a Mobile Money payment-instructions request flow.

## Current prototype status
- Android app source project created.
- Orders are composed and sent through WhatsApp.
- MTN MoMo/Airtel Money screen requests official payment instructions.
- This version does **not** process or verify payments, store orders in a cloud database, upload files, or provide an admin dashboard. Those require a secure backend and payment-provider/aggregator credentials.
- Sample gallery cards are placeholders. Replace them with the actual LUCKY GRAPHICS logo and portfolio images before publishing.

## Build the APK
1. Install Android Studio on a computer and install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version.
2. Open this folder (`lucky_graphics_android`) in Android Studio.
3. Allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
5. Test on a real Android phone before sharing. For public release, configure a signed release build and privacy policy.

## Before real Mobile Money payments
Choose a merchant/payment gateway that supports MTN MoMo and Airtel Money in Uganda. Obtain merchant credentials, create a server-side payment endpoint, verify provider callbacks on the server, and never put secret API keys in the Android app. Display payment success only after server-side verification.

## App details
- App name: LUCKY GRAPHICS
- Package: `com.luckygraphics.app`
- Version: 1.0.0
- Minimum Android: 6.0 (API 23)
